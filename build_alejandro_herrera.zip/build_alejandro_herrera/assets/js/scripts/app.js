// Foundation JavaScript
// Documentation can be found at: http://foundation.zurb.com/docs

$(document).on('ready page:load', function () {

Foundation.Interchange.SPECIAL_QUERIES['default'] = 'only screen and (min-width: 1401px)';
Foundation.Interchange.SPECIAL_QUERIES['large_1400'] = 'only screen and (min-width: 1025px) and (max-width: 1400px)';
Foundation.Interchange.SPECIAL_QUERIES['large_1024'] = 'only screen and (min-width: 769px) and (max-width: 1024px)';
Foundation.Interchange.SPECIAL_QUERIES['large_768'] = 'only screen and (min-width: 460px) and (max-width: 768px)';
Foundation.Interchange.SPECIAL_QUERIES['large_550'] = 'only screen and (max-width: 459px)';
$(function(){ $(document).foundation(); });
});


/*-------------------------------------------------------------------------------------*/
/* Document Ready
/*-------------------------------------------------------------------------------------*/
    (function($) {
        /*-------------------------------------------------------------------------------------*/
        /* Generales
        /*-------------------------------------------------------------------------------------*/
            var ventana= $(window).width();

            $(".digital").addClass("mover-digital");
            $(".intelligence").addClass("mover-intelligence");

            $('.menu-icon').click(function() {
                $(".menu-full-div").fadeToggle();

                if ( $(this).hasClass('no-click') ) {
                    $(this).attr('src','/wp-content/themes/mangle/assets/images/frontend/close.svg');
                    $("body").css("overflow","hidden");
                    $(this).removeClass('no-click');
                    $(this).addClass('click');
                    

                }
                else {
                    $(this).attr('src','/wp-content/themes/mangle/assets/images/frontend/menu.svg');
                    $("body").css("overflow","scroll");
                    $(this).removeClass('click');  
                    $(this).addClass('no-click');                    
                       
                }
            });

            var properties = [];
            properties.push({
                name: 'BUILD GDL',
                latitude: '20.682589',  
                longitude: '-103.425127',
                html: '<div class="descripcion-marcador"><p>BUILD GDL</p></div>',
                title: 'BUILD GDL',
                popup: true,
            });            
            newMap(properties);

            $(".ver-mx").click(function(){
                reload_map();
                var properties = [];
                properties.push({
                    name: 'BUIDL CDMX',
                    latitude: '19.509678',  
                    longitude: '-99.239293',
                    html: '<div class="descripcion-marcador"><p>BUILD CDMX</p></div>',
                    title: 'BUILD CDMX',
                    popup: true,
                });            
                newMap(properties);
            });

            $(".ver-gdl").click(function(){
                reload_map();
                var properties = [];
                properties.push({
                    name: 'BUILD GDL',
                    latitude: '20.682589',  
                    longitude: '-103.425127',
                    html: '<div class="descripcion-marcador"><p>BUILD GDL</p></div>',
                    title: 'BUILD GDL',
                    popup: true,
                });            
                newMap(properties);
            });

            $("#nosotros-menu").click(function(){
                $("html, body").animate({scrollTop:$(".certificaciones").offset().top-65},'slow');
                $(".menu-li li").removeClass('is-active');
                $("#nosotros-menu").parent().addClass('is-active');
            });

            $("#proyectos-menu").click(function(){
                $("html, body").animate({scrollTop:$(".proyectos").offset().top-65},'slow');
                $(".menu-li li").removeClass('is-active');
                $("#proyectos-menu").parent().addClass('is-active');
            });
            
            $("#servicios-menu").click(function(){
                $("html, body").animate({scrollTop:$(".certificaciones").offset().top-65},'slow');
                $(".menu-li li").removeClass('is-active');
                $("#servicios-menu").parent().addClass('is-active');
            });

            $("#contacto-menu").click(function(){
                $("html, body").animate({scrollTop:$(".contacto").offset().top-65},'slow');
                $(".menu-li li").removeClass('is-active');
                $("#contacto-menu").parent().addClass('is-active');
            });

            $("#proyectos-small").click(function(){
                $("html, body").animate({scrollTop:$(".proyectos").offset().top-65},'slow');
                $(".menu-small p").removeClass('is-active-small');
                $(this).addClass('is-active-small');
            });
            
            $("#servicios-small").click(function(){
                $("html, body").animate({scrollTop:$(".certificaciones").offset().top-65},'slow');
                $(".menu-small p").removeClass('is-active-small');
                $(this).addClass('is-active-small');
            });

            $("#contacto-small").click(function(){
                $("html, body").animate({scrollTop:$(".contacto").offset().top-65},'slow');
                $(".menu-small p").removeClass('is-active-small');
                $(this).addClass('is-active-small');
            });

            $("#burger").click(function(){
                $(".menu-small").fadeToggle();
                if( $("#parent_menu").hasClass("back-azul") ) {
                    $("#parent_menu").removeClass("back-azul");
                }
                else {
                    $("#parent_menu").addClass("back-azul");
                }

                if( $("#burger-icono").hasClass("fa-bars") ) {
                    $("#burger-icono").removeClass("fa-bars");
                    $("#burger-icono").addClass("fa-times");
                }
                else {
                    $("#burger-icono").removeClass("fa-times");
                    $("#burger-icono").addClass("fa-bars");
                }
            });

            $(window).scroll(sticky_reflow);
            sticky_reflow();
        ////////////////////////////////////////////////////////    END Generales

        /*-------------------------------------------------------------------------------------*/
        /* Owl Carousel
        /*-------------------------------------------------------------------------------------*/
            var owl = $('.owl-carousel');
            if (owl.children().length > 1) {
                $(".owl-carousel").owlCarousel({
                    items:1,
                    nav: false,
                    dots: true,
                    loop: true,
                    autoplay: false,
                });
            }
            else {
                $(".owl-carousel").owlCarousel({
                    items:1,
                    nav: false,
                    dots: false,
                    loop: false,
                });
            }

            var windowSize = $(window).width();

            if (windowSize > 768) { 
                var numero_item = 3;
            }
            else {
                var numero_item = 1;
            }

            $(".owl-carousel-ser").owlCarousel({
                items: numero_item,
                nav: false,
                dots: true,
                loop: true,
                autoplay: false,
                startPosition: 1,
                center: true,
                margin: 16,
            });
        ///////////////////////
            
    })(jQuery); 
////////////////////////////////////////////////////////    END DOCUMENT READY


/*-------------------------------------------------------------------------------------*/
/* Functions
/*-------------------------------------------------------------------------------------*/
    function newMap(properties){
        var center = [properties[0].latitude, properties[0].longitude];
        $('#new_map').gmap3({
            center: center,
            zoom: 16,
            mapTypeControl: false,
            zoomControl: true,
            scaleControl: true,
            streetViewControl: true,
            scrollwheel: false,
            mapTypeId : google.maps.MapTypeId.ROADMAP
        }).marker({
            position: center,
            icon: 'assets/images/marker-blue.png',
        }).infowindow({
            content: "<div class='info-marker'>"+properties[0].name+"</div>"
        }).then(function (infowindow) {
            var map = this.get(0);
            var marker = this.get(1);
            
                infowindow.open(map, marker);
            

        });
    }

    function reload_map() {
        jQuery('#new_map').gmap3({
            action: 'destroy'
        });
        var container = jQuery('#new_map').parent();
        jQuery('#new_map').remove();
        container.append('<div id="new_map"></div>');
    }

    function sticky_reflow() {
        var window_top = jQuery(window).scrollTop();
        var div_top = jQuery('#sticky-prev').offset().top;
        var divs = jQuery('.menu-div');
        var logo = jQuery('.logo-home');        

        if(window_top >= div_top){
            divs.addClass('sticky-menu');
            logo.attr("src","assets/images/build-blue.png");
        }
        else {
            divs.removeClass('sticky-menu');
            logo.attr("src","assets/images/build.png");
        }
        
    }
////////////////////////////////////////////////////////    END Functions
